%%%%%%%%%%%% Question 1
% k is the number of random points, exp is the number of experiences
% conducted, and required_time and estimated_pi all record the desired
% values for further uses.
exp = 6;
num_exp = (1:exp);

% skipping the experiment using 10 points.
k = 10.^(num_exp+ones(1,exp));
required_time = zeros(1,exp);
estimated_pi = zeros(1,exp);

% for loop record the time and the estimated pi for each experiment as the
% number of point is increased by multiplying 10.
for i = 1:exp
    tic
    est_pi = monte_carlo_est_pi(k(i));
    required_time(i) = toc;
    estimated_pi(i) = est_pi;
end

true_pi = pi*ones(1,exp);
error = abs(true_pi - estimated_pi);

figure
hold on 
plot(num_exp,estimated_pi,'-o')
plot(num_exp,true_pi,'-.')
title('estimated pi value vs the true pi value')
legend('estimated pi','true pi')
xlabel('the xth experiment')
hold off

figure
tiledlayout(2,1)

hold on
% plot the error value
ax1 = nexttile;
plot(ax1,num_exp,error,'-o')
title(ax1,'the absolute error')
ylabel(ax1,'abs error')
legend(ax1,'absolute error')
hold off

hold on
% plot the program running time 
ax2 = nexttile;
plot(ax2,num_exp,required_time,'-o')
title(ax2,'the program running time')
ylabel(ax2,'running time(s)')
xlabel(ax2, 'the xth experiment')
legend(ax2,'running time')
hold off

