%%%%%%%%%%%% Question 2
% digit: the number of significant to estimate the value of pi

digit = 2;

% If the variable graph_ind = true, the program plots the points as the
% points are being generated. However, it takes a long time to generate. To
% test the effect, please set graph_ind = true. If the variable graph_ind =
% false, the program plots all the points after all points are generated.

graph_ind = false;
[matrix, estimated_pre_pi, count, i] = monte_carlo_pre_est_pi(digit,graph_ind);

if graph_ind == true
    % the graph has been generated. Output the result
    fprintf(['The estimated pi value with the precision of within %d ' ...
    'significant is %f'], digit, estimated_pre_pi)
else
    % plot the graph manually
    % sort the matrix by the indicator
    matrix_sort = sortrows(matrix,3,'descend');

    % divide the matrix into two, one contains all the points outside the
    % circle, and one contains the points within the circle.
    matrix_out = matrix_sort(1:count,:);
    matrix_in = matrix_sort(count+1:i,:);
    
    figure
    title(['estimated pi value within ', num2str(digit), ' significant digits'])

    hold on
    xlim([-0.2, 1.2]);
    ylim([-0.2, 1.2]);

    plot(matrix_in(:,1),matrix_in(:,2),'b.')
    plot(matrix_out(:,1),matrix_out(:,2),'r.')

    % get the current axis;
    a = gca; 
    
    % set the width of the axis (the third value in Position) 
    % to be 60% of the Figure's width
    a.Position(3) = 0.6;
    
    % Draw a square
    sq_x = [0,1,1,0,0];
    sq_y = [0,0,1,1,0];
    plot(sq_x, sq_y, 'k-', 'LineWidth', 1);
    
    % Draw a quarter of a circle
    th = 0:pi/50:pi/2;
    xunit = cos(th) ;
    yunit = sin(th) ;
    plot(xunit, yunit,'k', 'LineWidth', 1);
    
    % put the textbox at 70% of the width and 
    % 10% of the height of the figure
    annotation('textbox', [0.7, 0.5, 0.1, 0.1], 'String', ...
        "pi' = " + estimated_pre_pi)
    grid on

    fprintf(['The estimated pi value with the precision of within %d ' ...
    'significant is %f'], digit, estimated_pre_pi)
end
