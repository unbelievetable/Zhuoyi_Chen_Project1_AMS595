% k is the total number of points used to estimate the value of pi
function estimated_pi = monte_carlo_est_pi(k)

    % random coordinates of (x,y)
    x = rand(k,1);
    y = rand(k,1);
    
    % record the points within the circle
    count = 0;
   
    % for loop going through all the points
    for i = 1:k
        % if the point is within the circle, change the indicator to 1
        if sqrt(x(i)^2+y(i)^2) < 1
            count = count + 1;
        end
    end
    
    % summation of the indicator is exactly the number of points within the
    % circle, and the value of pi/4 can be estimated by the number of
    % points within the circle divided by the total number of points.
    result = count/k;
    
    % compute the estimated pi
    estimated_pi = 4*result;
end