% the inputs of the function are
%   digit: the number of significant to estimate the value of pi
%   graph: the indicator to whether or not to plot the points while
%           generating.

% the outputs of the function are
%   matrix: containing all the points and indicator
%   estimated_pi: the estimated pi
%   count: number of points within the circle
%   i: number of loops, or total number of points
function [matrix, estimated_pi, count, i] = monte_carlo_pre_est_pi(digit,graph)
    arguments
        digit
        % assign the default value of graphing to be true
        graph = true
    end

    % over-estimated required size. Pre-allocation to speed up.
    k = 100^(digit+1);

    % pre-allocation random coordinates of (x,y)
    x = rand(k,1);
    y = rand(k,1);

    % indicator to show whethe22r a point is within the circle
    z = zeros(k,1);
    
    % record the points within the circle
    matrix = [x y z];
    count = 0;

    % compute the error. The error equals to the subtraction of the current
    % estimated pi value and the previous pi value.
    pre_pi = -inf;
    cur_pi = 0;
    error = cur_pi - pre_pi;
   
    % while loop until the error is less than the required significant
    % digit. Use i to record the number of loop.
    i = 0;

    % p-value to update the error every 10^p loop.
    p = 1;
    
    if graph == true
        %%%%%%%%%%%% If the graph indicator is true, this is the code to
        %%%%%%%%%%%% plot the points when generating them.
        figure
        hold all
        title(['estimated pi value within ', num2str(digit), ' significant digits'])
        xlabel('x-value')
        ylabel('y-value')
        
        % get the current axis;
        a = gca; 

        % set the width of the axis (the third value in Position) 
        % to be 60% of the Figure's width
        a.Position(3) = 0.6;

        % Draw a square
        sq_x = [0,1,1,0,0];
        sq_y = [0,0,1,1,0];
        plot(sq_x, sq_y, 'k-', 'LineWidth', 1);
        
        % Draw a quarter of a circle
        th = 0:pi/50:pi/2;
        xunit = cos(th) ;
        yunit = sin(th) ;
        plot(xunit, yunit,'k', 'LineWidth', 1);
        
        grid on

        xlim([-0.2, 1.2]);
        ylim([-0.2, 1.2]);
        drawnow
        while error > 10^(-digit+1)
            i = i + 1;
            
            % if the point is within the circle, change the indicator to 1
            if sqrt(x(i)^2+y(i)^2) < 1
                plot(x(i),y(i),'r.')
                drawnow
                matrix(i,3) = 1;
                count = count + 1;
            else
                plot(x(i),y(i),'b.')
                drawnow
            end
            
            % every 10^p step 
            if mod(i,100^p) == 0
                p = p + 1;
    
                % summation of the indicator is exactly the number of points 
                % within the circle, and the value of pi/4 can be estimated 
                % by the number of points within the circle divided by 
                % the total number of points. Note that the variable "count"
                % counts the number of points within the circle, and the
                % variable "i" counts the number of loops, or the total number
                % of points.
    
                estimated_pi = 4*count/i;
                pre_pi = cur_pi;
                cur_pi = estimated_pi;
                error = abs(cur_pi - pre_pi);
            end
        end
        % similarly, compute the estimated pi
        estimated_pi = 4*count/i;

        % put the textbox at 70% of the width and 
        % 10% of the height of the figure
        annotation('textbox', [0.7, 0.5, 0.1, 0.1], 'String', ...
            "estimated pi = " + estimated_pi)

    else
        %%%%%%%%%%%% If the graph indicator is false, this is the code
        %%%%%%%%%%%% without plotting points when generating
        while error > 10^(-digit+1)
            i = i + 1;
            
            % if the point is within the circle, change the indicator to 1
            if sqrt(x(i)^2+y(i)^2) < 1
                matrix(i,3) = 1;
                count = count + 1;
            end
            
            % every 10^p step 
            if mod(i,100^p) == 0
                p = p + 1;
    
                % summation of the indicator is exactly the number of points 
                % within the circle, and the value of pi/4 can be estimated 
                % by the number of points within the circle divided by 
                % the total number of points. Note that the variable "count"
                % counts the number of points within the circle, and the
                % variable "i" counts the number of loops, or the total number
                % of points.
    
                estimated_pi = 4*count/i;
                pre_pi = cur_pi;
                cur_pi = estimated_pi;
                error = abs(cur_pi - pre_pi);
            end
        end
    end    

    
    % truncate the matrix 
    matrix = matrix(1:i,:);
    
    % similarly, compute the estimated pi
    estimated_pi = 4*count/i;
end